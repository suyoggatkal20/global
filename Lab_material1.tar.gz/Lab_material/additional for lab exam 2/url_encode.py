def percent_encode(text):
    # Dictionary of characters to be encoded
    encoding_map = {
        ' ': '%20', '!': '%21', '"': '%22', '#': '%23', '$': '%24', 
        '%': '%25', '&': '%26', "'": '%27', '(': '%28', ')': '%29',
        '*': '%2A', '+': '%2B', ',': '%2C', '-': '%2D', '.': '%2E',
        '/': '%2F', ':': '%3A', ';': '%3B', '<': '%3C', '=': '%3D',
        '>': '%3E', '?': '%3F', '@': '%40', '[': '%5B', '\\': '%5C',
        ']': '%5D', '^': '%5E', '_': '%5F', '`': '%60', '{': '%7B',
        '|': '%7C', '}': '%7D', '~': '%7E'
    }
    
    encoded_text = ""
    for char in text:
        # Encode character if it's in the map; otherwise, keep it as is
        encoded_text += encoding_map.get(char, char if char.isalnum() else f'%{ord(char):02X}')
    
    return encoded_text

# Test the function
text = "Hello World! $&@"
print(percent_encode(text))
